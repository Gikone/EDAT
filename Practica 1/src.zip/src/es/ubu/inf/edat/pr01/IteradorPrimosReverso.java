/**
 *  Practica 1
 *  Diego Gonzalez Roman
 *  15/02/18
 *  v1.0
 */

package es.ubu.inf.edat.pr01;

public class IteradorPrimosReversoimplements Interator<Integer> {
	private int posicion = 2;
	
	public IteradorPrimosReverso{
		
	}
	public boolean hasPrevious() {
		
	}
	
	public Integer previous() {
		
	}
	
}
