/**
 *  Practica 1
 *  Diego Gonzalez Roman
 *  15/02/18
 *  v1.0
 */
package es.ubu.inf.edat.pr01;

import java.util.Iterator;




public class IteradorPrimos implements Iterator<Integer>  {
	private int posicion = 2;
	
	
	public IteradorPrimos() { 
		//Constructor vacio
	}

	public boolean hasNext() {
		return true;
	}
	
	public Integer next() {
		int numero = posicion + 1;
		boolean nEsPrimo;
		do {
			nEsPrimo = true;
			if (++numero % 2 == 0)
				continue;
			int maximo = (int) Math.sqrt(numero);
			for (int i = 2; i <= maximo; i++){
				if (numero % i == 0) {
					nEsPrimo = false;
					break;
				}
			}	
		}
		while (nEsPrimo);
		return numero;
			
		
	}
	
}
