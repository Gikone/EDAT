package es.ubu.inf.edat.pr02;

/**
 * Diego Gonzalez Roman
 * Practica 2    22/02/2018
 * v.1.0
 * 
 */

import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class ColeccionArray2D<E> extends AbstractCollection<E>{ 

	private E[][] elementos; 
	
	public ColeccionArray2D (E[][] cuadricula) {
		this.elementos = cuadricula;
	}
	

	private class Iterator2D implements Iterator<E>  { 
		private int posicion;
		
		public Iterator2D() {
			
		}
		private int largo() {
			return elementos.length;
			
		}
		
		private int ancho() {
			return elementos[0].length;
		}

		public boolean hasNext() {
			return posicion < ancho() * largo();
		
		} 

		public E next() {
			return elementos[posicion/(ancho)][posicion%(ancho)]
					
		} 

		private void remove() {
			elementos[posicion/(ancho)][posicion%(ancho)] = null;
		
		}
		
	}
	
}
